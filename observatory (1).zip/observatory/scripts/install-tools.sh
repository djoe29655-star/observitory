#!/usr/bin/env bash
set -euo pipefail

echo "== Observatory tool installer =="
echo

if command -v go >/dev/null 2>&1; then
  echo "[+] Installing Go-based tools..."
  go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest
  go install github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest
  go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest
  go install github.com/sensepost/gowitness@latest
  go install github.com/projectdiscovery/httpx/cmd/httpx@latest
  go install github.com/projectdiscovery/katana/cmd/katana@latest
  go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
  go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
  CGO_ENABLED=0 go install github.com/runZeroInc/sshamble@latest
else
  echo "[!] Go was not found. Install a current Go toolchain, then rerun this script."
fi

echo
echo "[+] Installing Python CLIs where possible..."
python3 -m pip install --upgrade shodan datalake-scripts || true

echo
if command -v nmap >/dev/null 2>&1; then
  echo "[+] nmap already installed."
else
  echo "[!] nmap is not installed."
  echo "    Debian/Ubuntu: sudo apt install nmap"
  echo "    macOS:         brew install nmap"
fi

echo
if command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1 || command -v google-chrome >/dev/null 2>&1; then
  echo "[+] Chrome/Chromium found for gowitness."
else
  echo "[!] Chrome/Chromium was not detected; gowitness screenshots may require it."
fi

echo
echo "[+] Done. Ensure \$HOME/go/bin is in PATH, then run:"
echo "    python -m observatory doctor"
