from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlparse


_HOST_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$"
)


def normalize_target(value: str) -> str:
    raw = value.strip()
    if not raw:
        raise ValueError("Target cannot be empty.")

    if "://" in raw:
        parsed = urlparse(raw)
        if not parsed.hostname:
            raise ValueError("Invalid URL target.")
        return parsed.hostname.lower()

    try:
        return str(ipaddress.ip_address(raw))
    except ValueError:
        pass

    # Support CIDR for tools that can consume it.
    try:
        return str(ipaddress.ip_network(raw, strict=False))
    except ValueError:
        pass

    candidate = raw.rstrip(".").lower()
    if not _HOST_RE.fullmatch(candidate):
        raise ValueError(
            "Target must be a hostname, IP address, CIDR, or URL with a valid hostname."
        )
    return candidate


def safe_slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", value)[:120]
