from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Sequence


class Stage(str, Enum):
    PASSIVE = "passive"
    ACTIVE = "active"
    MANUAL = "manual"


@dataclass(frozen=True)
class ToolSpec:
    name: str
    binaries: tuple[str, ...]
    stage: Stage
    description: str
    install_hint: str
    builder: Callable[[str, Path], Sequence[str]] | None = None
    optional: bool = False


@dataclass
class RunResult:
    tool: str
    command: list[str]
    returncode: int | None
    stdout_file: str | None = None
    stderr_file: str | None = None
    error: str | None = None
    duration_seconds: float | None = None


@dataclass
class ScanManifest:
    target: str
    mode: str
    authorised: bool
    started_at: str
    results: list[RunResult] = field(default_factory=list)
