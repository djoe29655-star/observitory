from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.table import Table

from .models import RunResult, ScanManifest, Stage, ToolSpec
from .targets import safe_slug
from .tools import TOOLS

console = Console()


def locate_binary(spec: ToolSpec) -> str | None:
    for binary in spec.binaries:
        path = shutil.which(binary)
        if path:
            return path
    return None


def doctor() -> int:
    table = Table(title="Observatory toolchain")
    table.add_column("Tool")
    table.add_column("Stage")
    table.add_column("Status")
    table.add_column("Purpose")

    missing = 0
    for spec in TOOLS.values():
        found = locate_binary(spec)
        if found:
            status = f"[green]installed[/green] ({Path(found).name})"
        else:
            status = "[yellow]missing[/yellow]" if spec.optional else "[red]missing[/red]"
            if not spec.optional:
                missing += 1
        table.add_row(spec.name, spec.stage.value, status, spec.description)

    console.print(table)
    if missing:
        console.print(
            f"\n[bold]Missing required/default tools:[/bold] {missing}. "
            "Run [cyan]bash scripts/install-tools.sh[/cyan] or install them manually."
        )
    return 0


def _write_manifest(path: Path, manifest: ScanManifest) -> None:
    payload = asdict(manifest)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _run_command(
    spec: ToolSpec,
    cmd: list[str],
    outdir: Path,
    timeout: int,
) -> RunResult:
    stdout_path = outdir / f"{spec.name}.stdout.txt"
    stderr_path = outdir / f"{spec.name}.stderr.txt"

    console.print(f"[cyan]→ {spec.name}[/cyan]  {' '.join(cmd)}")
    started = time.monotonic()

    try:
        proc = subprocess.run(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
            env=os.environ.copy(),
        )
        stdout_path.write_text(proc.stdout or "", encoding="utf-8", errors="replace")
        stderr_path.write_text(proc.stderr or "", encoding="utf-8", errors="replace")
        elapsed = round(time.monotonic() - started, 3)

        color = "green" if proc.returncode == 0 else "yellow"
        console.print(f"[{color}]  exit={proc.returncode} time={elapsed}s[/{color}]")

        return RunResult(
            tool=spec.name,
            command=cmd,
            returncode=proc.returncode,
            stdout_file=str(stdout_path),
            stderr_file=str(stderr_path),
            duration_seconds=elapsed,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = round(time.monotonic() - started, 3)
        return RunResult(
            tool=spec.name,
            command=cmd,
            returncode=None,
            stdout_file=str(stdout_path),
            stderr_file=str(stderr_path),
            error=f"Timed out after {timeout}s",
            duration_seconds=elapsed,
        )
    except OSError as exc:
        return RunResult(
            tool=spec.name,
            command=cmd,
            returncode=None,
            error=str(exc),
        )


def scan(
    target: str,
    mode: str,
    authorised: bool,
    results_root: Path,
    timeout: int = 300,
) -> Path:
    if mode in {"active", "full"} and not authorised:
        raise PermissionError(
            "Active scanning is locked. Re-run with --i-am-authorized only for a target "
            "you own or have explicit permission to test."
        )

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    outdir = results_root / f"{timestamp}-{safe_slug(target)}"
    outdir.mkdir(parents=True, exist_ok=True)

    manifest = ScanManifest(
        target=target,
        mode=mode,
        authorised=authorised,
        started_at=datetime.now(timezone.utc).isoformat(),
    )

    wanted_stages = {Stage.PASSIVE}
    if mode == "active":
        wanted_stages = {Stage.ACTIVE}
    elif mode == "full":
        wanted_stages = {Stage.PASSIVE, Stage.ACTIVE}

    for spec in TOOLS.values():
        if spec.stage not in wanted_stages:
            continue
        if spec.builder is None:
            console.print(f"[dim]↷ {spec.name}: manual/optional integration; skipped[/dim]")
            continue

        binary = locate_binary(spec)
        if not binary:
            console.print(f"[yellow]↷ {spec.name}: not installed; skipped[/yellow]")
            manifest.results.append(
                RunResult(
                    tool=spec.name,
                    command=[],
                    returncode=None,
                    error=f"Tool not installed. Hint: {spec.install_hint}",
                )
            )
            _write_manifest(outdir / "manifest.json", manifest)
            continue

        # Builder uses canonical binary name; replace it with the resolved binary path.
        cmd = list(spec.builder(target, outdir))
        cmd[0] = binary
        result = _run_command(spec, cmd, outdir, timeout)
        manifest.results.append(result)
        _write_manifest(outdir / "manifest.json", manifest)

    _write_manifest(outdir / "manifest.json", manifest)
    console.print(f"\n[bold green]Results:[/bold green] {outdir}")
    return outdir


def passthrough(tool_name: str, args: list[str], authorised: bool, timeout: int) -> int:
    if tool_name not in TOOLS:
        console.print(f"[red]Unknown tool:[/red] {tool_name}")
        return 2

    spec = TOOLS[tool_name]
    if spec.stage in {Stage.ACTIVE, Stage.MANUAL} and not authorised:
        console.print(
            "[red]This tool can perform direct target interaction.[/red] "
            "Use --i-am-authorized only for systems you are authorised to assess."
        )
        return 2

    binary = locate_binary(spec)
    if not binary:
        console.print(f"[red]{tool_name} is not installed.[/red] {spec.install_hint}")
        return 127

    try:
        proc = subprocess.run([binary, *args], timeout=timeout, check=False)
        return proc.returncode
    except subprocess.TimeoutExpired:
        console.print(f"[red]Timed out after {timeout}s[/red]")
        return 124
