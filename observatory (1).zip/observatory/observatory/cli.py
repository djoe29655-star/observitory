from __future__ import annotations

import argparse
from pathlib import Path

from rich.console import Console

from .runner import doctor, passthrough, scan
from .targets import normalize_target
from .tools import TOOLS

console = Console()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="observatory",
        description="OSINT and authorised security-recon orchestration.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Show installed/missing external tools.")

    scan_p = sub.add_parser("scan", help="Run an Observatory scan.")
    scan_p.add_argument("target", help="Hostname, IP, CIDR, or URL.")
    scan_p.add_argument(
        "--mode",
        choices=["passive", "active", "full"],
        default="passive",
        help="passive is the safe default; active/full require authorisation.",
    )
    scan_p.add_argument(
        "--i-am-authorized",
        action="store_true",
        help="Confirm you own the target or have explicit permission to test it.",
    )
    scan_p.add_argument(
        "--results-dir",
        default="results",
        help="Directory where scan results are stored.",
    )
    scan_p.add_argument(
        "--timeout",
        type=int,
        default=300,
        help="Per-tool timeout in seconds (default: 300).",
    )

    tool_p = sub.add_parser("tool", help="Run one included tool directly.")
    tool_p.add_argument("tool", choices=sorted(TOOLS))
    tool_p.add_argument(
        "--i-am-authorized",
        action="store_true",
        help="Required for active/manual tools.",
    )
    tool_p.add_argument(
        "--timeout",
        type=int,
        default=300,
        help="Command timeout in seconds.",
    )
    tool_p.add_argument(
        "tool_args",
        nargs=argparse.REMAINDER,
        help="Arguments passed to the underlying tool; use -- before them.",
    )

    sub.add_parser("tools", help="List supported Observatory integrations.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    ns = parser.parse_args(argv)

    if ns.command == "doctor":
        return doctor()

    if ns.command == "tools":
        for spec in TOOLS.values():
            console.print(
                f"[bold]{spec.name:10}[/bold] "
                f"[cyan]{spec.stage.value:7}[/cyan] {spec.description}"
            )
        return 0

    if ns.command == "scan":
        try:
            target = normalize_target(ns.target)
            scan(
                target=target,
                mode=ns.mode,
                authorised=ns.i_am_authorized,
                results_root=Path(ns.results_dir),
                timeout=ns.timeout,
            )
            return 0
        except (ValueError, PermissionError) as exc:
            console.print(f"[red]{exc}[/red]")
            return 2

    if ns.command == "tool":
        args = list(ns.tool_args)
        if args and args[0] == "--":
            args = args[1:]
        return passthrough(
            tool_name=ns.tool,
            args=args,
            authorised=ns.i_am_authorized,
            timeout=ns.timeout,
        )

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
