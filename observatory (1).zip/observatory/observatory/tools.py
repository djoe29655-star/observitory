from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from .models import Stage, ToolSpec


def _url(target: str) -> str:
    if target.startswith(("http://", "https://")):
        return target
    return f"https://{target}"


def asnmap_cmd(target: str, out: Path):
    return ["asnmap", "-d", target, "-json"]


def cdncheck_cmd(target: str, out: Path):
    return ["cdncheck", "-i", target, "-json"]


def dnsx_cmd(target: str, out: Path):
    return ["dnsx", "-d", target, "-a", "-aaaa", "-cname", "-mx", "-ns", "-txt", "-json"]


def shodan_cmd(target: str, out: Path):
    # `shodan host` works best for IPs. If a hostname is supplied, users can
    # still use passthrough mode for the exact Shodan query they want.
    return ["shodan", "host", target]


def httpx_cmd(target: str, out: Path):
    return [
        "httpx",
        "-u", _url(target),
        "-status-code",
        "-title",
        "-tech-detect",
        "-web-server",
        "-ip",
        "-cname",
        "-asn",
        "-cdn",
        "-json",
    ]


def katana_cmd(target: str, out: Path):
    return [
        "katana",
        "-u", _url(target),
        "-d", "2",
        "-jc",
        "-kf", "robotstxt,sitemapxml",
        "-jsonl",
    ]


def naabu_cmd(target: str, out: Path):
    return [
        "naabu",
        "-host", target,
        "-top-ports", "100",
        "-rate", "200",
        "-json",
    ]


def nmap_cmd(target: str, out: Path):
    return [
        "nmap",
        "-sV",
        "--version-light",
        "-T3",
        "--top-ports", "100",
        "-oX", str(out / "nmap.xml"),
        target,
    ]


def nuclei_cmd(target: str, out: Path):
    return [
        "nuclei",
        "-u", _url(target),
        "-severity", "info,low,medium,high,critical",
        "-rl", "20",
        "-jsonl",
    ]


def gowitness_cmd(target: str, out: Path):
    screenshots = out / "screenshots"
    screenshots.mkdir(parents=True, exist_ok=True)
    return [
        "gowitness",
        "scan", "single",
        "--url", _url(target),
        "--screenshot-path", str(screenshots),
    ]


TOOLS: dict[str, ToolSpec] = {
    "asnmap": ToolSpec(
        "asnmap", ("asnmap",), Stage.PASSIVE,
        "ASN / CIDR enrichment.",
        "go install github.com/projectdiscovery/asnmap/cmd/asnmap@latest",
        asnmap_cmd,
    ),
    "cdncheck": ToolSpec(
        "cdncheck", ("cdncheck",), Stage.PASSIVE,
        "CDN, cloud and WAF identification.",
        "go install github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest",
        cdncheck_cmd,
    ),
    "datalake": ToolSpec(
        "datalake", ("ocd-dtl", "datalake"), Stage.PASSIVE,
        "Threat-intelligence / Datalake integration. Manual command selection is recommended.",
        "pip install datalake-scripts",
        None,
        optional=True,
    ),
    "dnsx": ToolSpec(
        "dnsx", ("dnsx",), Stage.PASSIVE,
        "DNS records and resolution.",
        "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
        dnsx_cmd,
    ),
    "gowitness": ToolSpec(
        "gowitness", ("gowitness",), Stage.ACTIVE,
        "Headless browser screenshots and web metadata.",
        "go install github.com/sensepost/gowitness@latest",
        gowitness_cmd,
    ),
    "httpx": ToolSpec(
        "httpx", ("httpx",), Stage.ACTIVE,
        "HTTP metadata and technology probing.",
        "go install github.com/projectdiscovery/httpx/cmd/httpx@latest",
        httpx_cmd,
    ),
    "katana": ToolSpec(
        "katana", ("katana",), Stage.ACTIVE,
        "Web crawler / endpoint discovery.",
        "go install github.com/projectdiscovery/katana/cmd/katana@latest",
        katana_cmd,
    ),
    "naabu": ToolSpec(
        "naabu", ("naabu",), Stage.ACTIVE,
        "Fast port enumeration.",
        "go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
        naabu_cmd,
    ),
    "nmap": ToolSpec(
        "nmap", ("nmap",), Stage.ACTIVE,
        "Service and version enumeration.",
        "Install with your OS package manager (apt/brew).",
        nmap_cmd,
    ),
    "nuclei": ToolSpec(
        "nuclei", ("nuclei",), Stage.ACTIVE,
        "Template-based vulnerability detection.",
        "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
        nuclei_cmd,
    ),
    "shodan": ToolSpec(
        "shodan", ("shodan",), Stage.PASSIVE,
        "Internet exposure intelligence.",
        "pip install shodan",
        shodan_cmd,
        optional=True,
    ),
    "sshamble": ToolSpec(
        "sshamble", ("sshamble",), Stage.MANUAL,
        "SSH research/scanning tool. Kept manual-by-default.",
        "go install github.com/runZeroInc/sshamble@latest",
        None,
        optional=True,
    ),
}
