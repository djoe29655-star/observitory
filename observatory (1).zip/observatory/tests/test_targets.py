import unittest

from observatory.targets import normalize_target, safe_slug


class TargetTests(unittest.TestCase):
    def test_domain(self):
        self.assertEqual(normalize_target("Example.COM"), "example.com")

    def test_url(self):
        self.assertEqual(
            normalize_target("https://example.com/path?q=1"),
            "example.com",
        )

    def test_ip(self):
        self.assertEqual(normalize_target("192.0.2.10"), "192.0.2.10")

    def test_cidr(self):
        self.assertEqual(normalize_target("192.0.2.5/24"), "192.0.2.0/24")

    def test_invalid(self):
        with self.assertRaises(ValueError):
            normalize_target("example.com; rm -rf /")

    def test_slug(self):
        self.assertEqual(safe_slug("example.com/hello"), "example.com_hello")


if __name__ == "__main__":
    unittest.main()
