# Observatory

**Observatory** is a modular OSINT and authorised security-recon orchestration CLI.

It does not reimplement the underlying scanners. Instead, it detects and safely orchestrates a curated toolchain:

- `asnmap`
- `cdncheck`
- `datalake` / Orange Cyberdefense Datalake (`ocd-dtl`)
- `dnsx`
- `gowitness`
- `httpx`
- `katana`
- `naabu`
- `nmap`
- `nuclei`
- `shodan`
- `sshamble`

## Design

Observatory has three modes:

- **passive** — public/OSINT-oriented enrichment and low-impact lookups
- **active** — direct network/web probing; requires `--i-am-authorized`
- **full** — runs both passive and active stages; requires `--i-am-authorized`

Active scanning must only be used on systems you own or have explicit permission to assess.

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python -m observatory doctor
python -m observatory scan example.com --mode passive
```

For an authorised target:

```bash
python -m observatory scan example.com \
  --mode full \
  --i-am-authorized
```

Results are written to `results/<timestamp>-<target>/`.

## Tool passthrough

Observatory can also act as a launcher for any included tool:

```bash
python -m observatory tool httpx -- -h
python -m observatory tool nuclei -- -h
python -m observatory tool nmap -- -sV scanme.nmap.org
```

The `--` separates Observatory arguments from the underlying tool arguments.

## Install the external tools

On a Linux/macOS workstation with Go installed:

```bash
bash scripts/install-tools.sh
```

The script prints or performs the recommended installs where practical. Some tools require system packages or credentials.

### Credentials

Keep credentials out of Git.

Use environment variables where supported:

```bash
export SHODAN_API_KEY="..."
export OCD_DTL_TOKEN="..."
```

`.env` is ignored by Git.

## Tool notes

| Tool | Purpose | Default stage |
|---|---|---|
| asnmap | ASN / network-range enrichment | passive |
| cdncheck | CDN / cloud / WAF identification | passive |
| datalake / ocd-dtl | threat-intelligence lookup | passive / optional |
| dnsx | DNS resolution and records | passive |
| shodan | internet exposure intelligence | passive / optional |
| httpx | HTTP probing / metadata | active |
| katana | web crawling / endpoint discovery | active |
| naabu | port enumeration | active |
| nmap | service/version enumeration | active |
| nuclei | template-based vulnerability detection | active |
| gowitness | web screenshots | active |
| sshamble | SSH research/scanning utility | active / manual-by-default |

`datalake` is treated as an optional integration because Orange Cyberdefense Datalake authentication and available commands depend on the account/environment.

`sshamble` is present in the registry and installer, but is not executed automatically in the default pipeline. Use explicit passthrough after confirming scope and the command you want to run.

## Safety controls

Observatory intentionally:

- does **not** use `shell=True`
- validates targets before building commands
- keeps active stages locked unless `--i-am-authorized` is supplied
- rate-limits the default Nuclei run
- uses top-100 ports for Naabu by default
- stores every command and exit code in `manifest.json`
- does not place API keys into command-line output where avoidable

## Repo layout

```text
observatory/
├── observatory/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py
│   ├── models.py
│   ├── runner.py
│   ├── targets.py
│   └── tools.py
├── scripts/
│   └── install-tools.sh
├── tests/
│   └── test_targets.py
├── results/
│   └── .gitkeep
├── .env.example
├── .gitignore
├── LICENSE
├── pyproject.toml
└── requirements.txt
```

## Roadmap

- HTML report/dashboard
- job queue + scan history
- configurable profiles
- per-tool timeouts/concurrency
- scope allowlists
- JSON normalisation across tool outputs
- Docker image
- web UI
